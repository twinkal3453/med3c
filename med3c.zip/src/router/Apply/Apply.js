import React from "react";
import Footer from "../footer/footer";
import apply from "../../Assets/apply.svg";
import "./Apply.scss";

function Apply() {
  return (
    <div className="apply">
      <div className="res">
        {/* this divs are only for design */}
        <div className="apply_form">
          <span className="circle_one"></span>
          <span className="circle_two">
            <span className="circle_three"></span>
          </span>

          {/* form content written here */}
          <div className="form_content">
            <div className="image_div">
              <img className="imoge" src={apply} alt="imoge" />
            </div>
            <div className="form_inputs">
              <input
                className="text_input"
                type="text"
                id="name"
                placeholder="Name..."
              />
              <input
                className="text_input"
                type="text"
                id="passport"
                placeholder="Passport number..."
              />
              <input
                className="text_input"
                type="text"
                id="university"
                placeholder="University applying for..."
              />
              <input
                className="text_input"
                type="text"
                id="course"
                placeholder="Course applying for..."
              />
              <input
                className="text_input"
                type="text"
                id="contact"
                placeholder="Contact number..."
              />
              <input
                className="text_input"
                type="text"
                id="email"
                placeholder="Email id..."
              />
              <button className="submit_btn">Apply</button>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Apply;
