import React from "react";
import {
  University_Name,
  Specs,
  Strecture,
  UniversityDiscription,
} from "./universityList";
import Footer from "../footer/footer";
import "./universityName.scss";

const University = ({ match }) => {
  const universityName = match.params.universityName;
  const countryName = match.params.countryName;

  console.log(countryName, universityName);

  return (
    <div className="home">
      <div className="sec">
        <div id="sec1">
          {University_Name.map((item, index) => {
            return (
              <div className="container_img" key={index}>
                <img className="imoge" src={item.image} alt="imoge" />
                <div className="university_name">
                  <h1> {item.name} </h1>
                </div>
              </div>
            );
          })}
        </div>

        <div id="sec2">
          {/* <img src={illustration} alt="illustration" /> */}
          <div className="container_2">
            <div className="container_div">
              <div className="container_text">
                {Specs.map((item, index) => {
                  return (
                    <div className="specs" key={index}>
                      <p>
                        <span>
                          <img src={item.arrow} alt="arrow" />
                        </span>
                        {item.data}
                      </p>
                    </div>
                  );
                })}
              </div>
              <div className="line"></div>
              <div className="container_fee">
                <div className="container_main">
                  <div className="container_head">
                    <p>Tution fees also can be paid on half yearly</p>
                    <h3>Fee Stuecture:-</h3>
                  </div>
                  {Strecture.map((item, index) => {
                    return (
                      <div className="table_data" key={index}>
                        <table>
                          <tr>
                            <th> {item.year} </th>
                            <th> {item.year2} </th>
                            <th> {item.year3} </th>
                          </tr>
                          <tr>
                            <td>
                              {item.doller} <br /> {item.rupee}
                            </td>
                            <td>
                              {item.doller2} <br /> {item.rupee2}
                            </td>
                            <td>
                              {item.doller3} <br /> {item.rupee3}
                            </td>
                          </tr>
                        </table>
                      </div>
                    );
                  })}
                </div>

                <span className="circle"></span>
                <span className="circle1"></span>
              </div>
            </div>
          </div>
        </div>

        {/* section 3 */}
        <div id="sec3">
          {UniversityDiscription.map((item, index) => {
            return (
              <div className="container_1" key={index}>
                <h2>{item.name}</h2>
                <p> {item.discription} </p>
                <p> {item.discription2} </p>
                <p> {item.discription3} </p>

                <div className="container_btn">
                  <p> {item.button} </p>
                  <button>Contact Us</button>
                </div>
              </div>
            );
          })}
        </div>
        <Footer />
      </div>
    </div>
  );
};

export default University;
