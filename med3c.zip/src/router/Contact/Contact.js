import React from "react";
import Footer from "../footer/footer";
import contact from "../../Assets/contactus.jpg";
import "./Contact.scss";

function Contact() {
  return (
    <div className="contact">
      <div className="res">
        <img className="imoge" src={contact} alt="doctor" />
        {/* card of form inputs */}
        <div className="container_1">
          <div className="container_data">
            <div className="card_container">
              <div className="card">
                <div className="text">
                  <h3>Contact Us:</h3>
                </div>

                <div id="inputfield_div">
                  <input
                    className="inputfield"
                    type="text"
                    name="Name"
                    id="name"
                    placeholder="Name..."
                  />
                  <input
                    className="inputfield"
                    type="text"
                    name="Email"
                    id="email"
                    placeholder="Email..."
                  />
                  <input
                    className="inputfield"
                    type="text"
                    name="Phone"
                    id="phone"
                    placeholder="Phone..."
                  />
                  <textarea
                    type="text"
                    className="message"
                    name="Message"
                    id="message"
                    placeholder="Message..."
                  />
                  <button className="button_btn">SEND</button>
                </div>
              </div>
            </div>

            {/* address details */}
            <div className="address_container">
              <div className="address_text">
                <h2>Our head office: </h2>
                <div className="area">
                  <i class="fas fa-map-marker-alt"></i>
                  <p className="address_area">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. A
                    totam quaerat eligendi saepe ex dolor aperiam blanditiis?
                    Quidem, quaerat voluptatibus provident excepturi,
                  </p>
                </div>

                {/* mobile details */}
                <div className="mobile">
                  <i class="fas fa-phone-alt"></i>
                  <div className="line">
                    <p className="mob-1">+ 91-3847484574</p>
                    <p className="mob-2">+91-3847484574</p>
                  </div>
                </div>

                {/* email details */}
                <div className="email">
                  <i class="fas fa-envelope"></i>

                  <div className="line">
                    <p className="email_1">dream234@gmail.com</p>
                    <p className="email-2">abcdef123@med.co.in</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Contact;
