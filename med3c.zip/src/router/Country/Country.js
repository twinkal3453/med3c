import React from "react";
import { Link } from "react-router-dom";
import Footer from "../footer/footer";
import arrow from "../../Assets/arrow.svg";
import illustration from "../../Assets/illustration.svg";
import { CountryList } from "./countryName";
import "./Country.scss";

function Country() {
  return (
    <div className="country">
      <div className="res">
        <div className="whole_page">
          {/* this is for designing that are shown in the page */}
          <div className="circle_1"></div>
          <div className="circle_2"></div>
          <div className="circle_3"></div>
          <div className="circle_4"></div>
          <div className="circle_5">
            <img className="illustration" src={illustration} alt="" />
          </div>
        </div>

        {/* this is for content that is writter below */}
        <div className="abs">
          <div className="main">
            <div className="card1">
              <h2 className="heading">
                Our featured <br /> countries are here...
              </h2>
              <i className="fas fa-arrow-right"></i>
            </div>

            {CountryList.map((item, index) => {
              return (
                <div className={item.cName} key={index}>
                  <div className="pic">
                    <img className="imoge" src={item.pic} alt="" />
                    <div className="name">
                      <h2 className="text"> {item.name} </h2>
                    </div>
                  </div>

                  <div className="content">
                    <p> {item.disc} </p>
                    <div className="box">
                      <div className="data">
                        <p>Capital:-</p>
                        <p> {item.capital} </p>
                      </div>
                      <div
                        style={{ background: "rgb(205, 249, 255)" }}
                        className="data1"
                      >
                        <p>Currency:-</p>
                        <p> {item.currency} </p>
                      </div>
                      <div className="data1">
                        <p>Calling code:-</p>
                        <p> {item.calling} </p>
                      </div>
                      <div
                        style={{ background: "rgb(205, 249, 255)" }}
                        className="data1"
                      >
                        <p>Time:-</p>
                        <p> {item.time} </p>
                      </div>
                      <div className="data1">
                        <p>Religion:-</p>
                        <p> {item.religion} </p>
                      </div>
                      <div
                        style={{ background: "rgb(205, 249, 255)" }}
                        className="data1"
                      >
                        <p>Language:-</p>
                        <p> {item.language} </p>
                      </div>
                      <div className="data1">
                        <p>Living:-</p>
                        <p> {item.living} </p>
                      </div>
                    </div>
                    {/* button */}
                    <Link className="link_button" to={`/country/${item.name}`}>
                      <button className="read_btn">Read more</button>
                    </Link>
                  </div>
                </div>
              );
            })}

            <div className="card8">
              <h2 className="heading">
                Our featured <br /> countries are here...
              </h2>
              <button className="button">
                <img src={arrow} alt="arrow" />
              </button>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  );
}

export default Country;
