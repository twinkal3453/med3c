import flag from "../../../Assets/Ukraine Flag.png";
import karajin from "../../../Assets/Karajin.jpg";
import girl from "../../../Assets/girl.jpg";
import girl2 from "../../../Assets/hovering girl.jpg";

export const Home = [
  {
    cName: "imoge",
    image: flag,
    Country: "Ukraine",
  },
];

export const Universities = [
  {
    cName: "university",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university2",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university3",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university4",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university5",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university6",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university7",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university8",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university9",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university10",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university11",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
  {
    cName: "university12",
    name: karajin,
    university: "Lorem Ipsum falna university",
    money_1: "7200USD",
    rupee: "(5,94,000INR)",
    money_2: "4300USD",
    rupee2: "(3,01,000INR)",
    money_3: "28,700USD",
    rupee3: "(20,09,000INR)",
    converter: "*note - 1USD - 75INR(Approx for calculation)",
  },
];

export const Package = [
  {
    data: "Registration fee",
  },
  {
    data: "Admission process fee",
  },
  {
    data: "College fee",
  },
  {
    data: "Hostel fee",
  },
  {
    data: "6 years country visa fee",
  },
  {
    data: "Medical insurance fee",
  },
  {
    data: "Documentation fee",
  },
  {
    data: "Airport to Hostel Pickup charge. etc",
  },
];

export const Documents = [
  {
    data: " One set of photocopies of marks sheet of 10+2",
  },
  {
    data: "A valid passport (if you have)",
  },
  {
    data: "2 photographs, size 3×4 cm, black and white on non-glossy paper",
  },
  {
    data: "Registration amount of $500 (Rs. 30,000) as draft or bank deposit",
  },
];

export const Image = [
  {
    image: girl,
  },
];

export const Image2 = [
  {
    image: girl2,
  },
];

export const Services = [
  {
    data: "Receiving Official Admission Letter from the concerned university.",
  },
  {
    data:
      "Receiving Visa Support Letter issued by Department of Higher Education in Ukraine.",
  },
  {
    data: "Student Pick-up facility from the airport in Ukraine.",
  },
  {
    data:
      " Ample support service to the student regarding immigration clearance in Ukraine.",
  },
  {
    data:
      "Making arrangements for student ID card, hostel card, and international student card.",
  },
  {
    data: "Assistance in Visa renewal during the entire period of study.",
  },
  {
    data: " Individual room assistance for student",
  },
  {
    data: "Airport to Hostel Pickup Charges etc.",
  },
  {
    data:
      "Special orientation programs held for international students so that they can intermingle with the local environment.",
  },
  {
    data: "We act as student guardian throughout the period of the course.",
  },
];

export const Members = [
  {
    data: " World Health Organization (WHO).",
  },
  {
    data: " Medical Council of India(MCI)..",
  },
  {
    data: " United Nations Organization(UNO).",
  },
  {
    data: " International Association of Universities(IAU).",
  },
  {
    data: " European Universities Association (EUA).",
  },
  {
    data: " European Association of International Education(EAIE).",
  },
  {
    data: "World Federation of medical education(WFME).",
  },
  {
    data: "Association of medical education of Europe(AMEE).",
  },
  {
    data: " International Education Society (IES, London).",
  },
  {
    data: "International Education Society(IES).",
  },
  {
    data: " European Credit Transfer System (ECTS), etc.",
  },
];
