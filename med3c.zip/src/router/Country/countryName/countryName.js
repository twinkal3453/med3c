import React from "react";
import { Link } from "react-router-dom";
import {
  Home,
  Universities,
  Package,
  Documents,
  Image,
  Image2,
  Services,
  Members,
} from "./CountryUniversityList";
import arrow from "../../../Assets/arrow.svg";
import "./countryName.scss";
import Footer from "../../footer/footer";

function CountryName({ match }) {
  const countryName = match.params.countryName;
  console.log(countryName);

  return (
    <div className="home">
      <div className="res">
        {Home.map((item, index) => {
          return (
            <div className="sec1" key={index}>
              <div className="sec1_main">
                <img src={item.image} alt="" className={item.cName} />
              </div>
              <div className="name_container">
                <div className="heading">
                  <h1> {item.Country} </h1>
                </div>
                <button className="btn_arrow">
                  <img src={arrow} alt="arrow" />
                </button>
              </div>
            </div>
          );
        })}

        <div className="sec2">
          <div className="name">
            <div className="name_text">
              <h1>Universities</h1>
              <div className="line"></div>
            </div>
          </div>

          <div id="container">
            <div className="container_grid">
              {Universities.map((item, index) => {
                return (
                  <div className="card_text" key={index}>
                    <div className=".container_pic image_container">
                      <img className="imoge" src={item.name} alt="imoge" />
                    </div>
                    <div className="container_data">
                      <h3> {item.university} </h3>
                      <div className="table">
                        <table>
                          <tr>
                            <th>1st Year</th>
                            <th>
                              2nd to <br />
                              6th Years
                            </th>
                            <th>
                              Total Course
                              <br /> fee(6 Years)
                            </th>
                          </tr>
                          <tr>
                            <td>
                              {item.money_1}
                              <br />
                              {item.rupee}
                            </td>
                            <td>
                              {item.money_2}
                              <br />
                              {item.rupee2}
                            </td>
                            <td>
                              {item.money_3}
                              <br />
                              {item.rupee3}
                            </td>
                          </tr>
                        </table>
                        <p> {item.converter} </p>
                        <Link
                          className="link_button"
                          to={`/country/${countryName}/${item.university}`}
                        >
                          <button className="btn_submit">Read more</button>
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="sec3">
          <div className="container_0">
            <div className="containers container_1">
              <h3>1st Year package includes...</h3>
              {Package.map((item, index) => {
                return (
                  <div className="package" key={index}>
                    <ul>
                      <li>
                        <span>
                          <img className="arrow" src={arrow} alt="" />
                        </span>
                        {item.data}
                      </li>
                    </ul>
                  </div>
                );
              })}
            </div>
            <div className="containers container_2">
              <h3>Required documents for registration</h3>
              {Documents.map((item, index) => {
                return (
                  <div className="documents" key={index}>
                    <ul>
                      <li>
                        <span>
                          <img className="arrow" src={arrow} alt="" />
                        </span>
                        {item.data}
                      </li>
                    </ul>
                  </div>
                );
              })}
              <table>
                <tr>
                  <th>ELIGIBILITY</th>
                  <th>DURATION</th>
                  <th>INTAKE</th>
                  <th>HOLIDAYS</th>
                </tr>
                <tr>
                  <td>12th Science/A Level PCB (Physics-Chemistry-Biology)</td>
                  <td>5.8 Years</td>
                  <td>Sep 1st week</td>
                  <td>July & August</td>
                </tr>
              </table>
            </div>
            <div className="containers container_3">
              {Image.map((item, index) => {
                return (
                  <div className="tag_image" key={index}>
                    <img className="imoge" src={item.image} alt="imoge" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="sec4">
          <div className="container_1">
            <div className="container_main">
              <div className="container_image">
                {Image2.map((item, index) => {
                  return (
                    <img
                      key={index}
                      src={item.image}
                      alt="imoge"
                      className="imoge"
                    />
                  );
                })}
              </div>

              <div className="container_text">
                <div className="services">
                  <h3>*Our Services:-</h3>
                  {Services.map((item, index) => {
                    return (
                      <div className="services_list" key={index}>
                        <ul>
                          <li>
                            <span>
                              <img src={arrow} alt="" />
                            </span>
                            {item.data}
                          </li>
                        </ul>
                      </div>
                    );
                  })}
                </div>
                <div className="members">
                  <h3>
                    *All of the colleges are Members of the following
                    International organizations.
                  </h3>
                  {Members.map((item, index) => {
                    return (
                      <div className="members_list" key={index}>
                        <ul>
                          <li>
                            <span>
                              <img src={arrow} alt="" />
                            </span>
                            {item.data}
                          </li>
                        </ul>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
}

export default CountryName;
