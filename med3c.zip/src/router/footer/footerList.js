export const FooterList = [
  {
    url: "/",
    title: "Home",
  },
  {
    url: "/about",
    title: "About Us",
  },
  {
    url: "/country",
    title: "Country",
  },
  {
    url: "/contact",
    title: "Contact",
  },
  {
    url: "/apply",
    title: "Apply",
  },
];

export const UniversityLink = [
  {
    url: "/#",
    title: "MBBS in Ukraine",
  },
  {
    url: "/#",
    title: "MBBS in Kyrgyzstan",
  },
  {
    url: "/#",
    title: "MBBS in Philippines",
  },
  {
    url: "/#",
    title: "MBBS in Russia",
  },
  {
    url: "/#",
    title: "MBBS in China",
  },
];

export const SocialLinks = [
  {
    url: "https://www.instagram.com/care.medoverseas/?igshid=13p022ntxugk8",
    cName: "fab fa-instagram",
  },
  {
    url: "https://www.facebook.com/care.medoverseas/",
    cName: "fab fa-facebook-f",
  },
  {
    url: "https://wa.me/15551234567",
    cName: "fab fa-whatsapp",
  },
];
