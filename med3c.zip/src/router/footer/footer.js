import React from "react";
import { Link } from "react-router-dom";
import { FooterList, UniversityLink, SocialLinks } from "./footerList";
import "./footer.scss";

const Footer = () => {
  return (
    <footer id="footer">
      <div className="footer_container">
        <div className="footer_links">
          <div className="link">
            <h6>Quick links</h6>
            {FooterList.map((item, index) => {
              return (
                <div key={index}>
                  <Link className="link_list" to={item.url}>
                    <p>{item.title}</p>
                  </Link>
                </div>
              );
            })}
          </div>
          <div className="abroad">
            <h6>MBBS Abroad</h6>
            {UniversityLink.map((item, index) => {
              return (
                <div key={index}>
                  <Link className="link_list2" to={item.url}>
                    <p> {item.title} </p>
                  </Link>
                </div>
              );
            })}
          </div>
          <div className="address">
            <h6>Our Contact</h6>
            <div>
              <p className="med">
                Create Career with Care Med Overseas Educational consultants
              </p>
              <p className="adres">
                <span>
                  <i className="fas fa-map-marker-alt"></i>
                </span>{" "}
                Gf 640, Near Scope Hospital, Niti Khand 1, Indirapuram,
                Ghaziabad, UP Pincode: 201010
              </p>
            </div>
          </div>
          <div className="contact-us">
            <h6>Contact Us</h6>

            <div className="data">
              <div className="mob">
                <p>
                  <span>
                    <i className="fas fa-phone-alt"></i>
                  </span>{" "}
                  +91-4552323232
                </p>
                <p>
                  <span>
                    <i className="fas fa-phone-alt"></i>
                  </span>{" "}
                  +91-4552323232
                </p>
                <p>
                  <span>
                    <i className="far fa-envelope"></i>
                  </span>{" "}
                  span123@gmail.com
                </p>
              </div>
              <div className="social">
                <h6>Follow us: </h6>
                {SocialLinks.map((item, index) => {
                  return (
                    <span className="social_link" key={index}>
                      <a href={item.url}>
                        <i className={item.cName}></i>
                      </a>
                    </span>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="company">
        <p>
          &copy; 3C Med overseas All right reserved. | Designed by{" "}
          <span>Hind Corporation </span>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
