export const MenuItems = [
  {
    title: "HOME",
    url: "/",
    cName: "nav-links",
  },
  {
    title: "ABOUT",
    url: "/about",
    cName: "nav-links",
  },
  {
    title: "COUNTRY",
    url: "/country",
    cName: "nav-links",
  },
  {
    title: "CONTACT",
    url: "/contact",
    cName: "nav-links",
  },
  {
    title: "APPLY",
    url: "/apply",
    cName: "nav-links",
  },
];
