import React from "react";
import Nav from "./router/Nav/Nav";
import Home from "./router/Home/Home";
import About from "./router/About/About";
import Country from "./router/Country/Country";
import countryName from "./router/Country/countryName/countryName";
import universityName from "./router/universityName/universityName";
import Contact from "./router/Contact/Contact";
import Apply from "./router/Apply/Apply";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "./App.scss";

function App() {
  return (
    <Router basename="v2">
      <div className="App">
        <Nav />
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/about" component={About} />
          <Route exact path="/country" component={Country} />
          <Route exact path="/country/:countryName" component={countryName} />
          <Route
            path="/country/:countryName/:universityName"
            component={universityName}
          />
          <Route path="/contact" component={Contact} />
          <Route path="/Apply" component={Apply} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
