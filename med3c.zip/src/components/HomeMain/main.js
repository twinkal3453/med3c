import React from "react";
import "./style.css";
import { carousel } from "../../router/Home/HomeList";

const Main = () => {
  return (
    <div className="mainCarousel">
      {carousel.map((item, index) => {
        return (
          <div className="main" key={index}>
            <div className={item.cName}>
              <img className="slider_image" src={item.images} alt=" imoge" />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Main;
